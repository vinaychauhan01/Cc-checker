<?php

$botToken =  "5412995335:AAEgEsbB8vwBl7TnUucv4ICHDq61yIb24ow";
$website = "https://api.telegram.org/bot".$botToken;
$update = file_get_contents('php://input');
echo $update;
$update = json_decode($update, TRUE);
global $website;
$e = print_r($update);
$cchatid2 = $update["callback_query"]["message"]["chat"]["id"];
$cmessage_id2 = $update["callback_query"]["message"]["message_id"];
$cdata2 = $update["callback_query"]["data"];
$username = $update["message"]["from"]["username"];
$chatId = $update["message"]["chat"]["id"]; 
$chatusername = $update["message"]["chat"]["username"]; 
$chatname = $update["message"]["chat"]["title"]; 
$gId = $update["message"]["from"]["id"];
$userId = $update["message"]["from"]["id"]; 
$firstname = $update["message"]["from"]["first_name"]; 
$username = $update["message"]["from"]["username"]; 
$message = $update["message"]["text"]; 
$new_chat_member = $update["message"]["new_chat_member"];
$newusername = $update["message"]["new_chat_member"]["username"];
$newgId = $update["message"]["new_chat_member"]["id"];
$newfirstname = $update["message"]["new_chat_member"]["first_name"];
$message_id = $update["message"]["message_id"]; 
$r_id = $update["message"]["reply_to_message"];
$r_userId = $update["message"]["reply_to_message"]["from"]["id"];  
$r_firstname = $update["message"]["reply_to_message"]["from"]["first_name"];  
$r_username = $update["message"]["reply_to_message"]["from"]["username"]; 
$r_msg_id = $update["message"]["reply_to_message"]["message_id"]; 
$r_msg = $update["message"]["reply_to_message"]["text"]; 
$sender_chat = $update["message"]["sender_chat"]["type"]; 
$bot_name = "MI BOT USERNAME";
$owner = "@Devilsx19";
$keyboard = json_encode([
    'inline_keyboard' => [
    [['text' => "Propietario 🧑‍💻", 'url' => "https://t.me/aboutdevilsx19 "],],
    ]]);


    if ($cdata2 == "gates"){

        $keyboard = [
        'inline_keyboard' => [
             [
             ['text' => 'Tools🛠', 'callback_data' => 'herr']
             ],
             [
             ['text' => 'Exit 🔄️', 'callback_data' => 'exit']
             ],
       ]
    ];
    $freecmands = urlencode("<b>$bot_name

Stripe [OFF❌] = /chk
    </b>");
    $free = json_encode($keyboard);
            file_get_contents("https://api.telegram.org/bot$botToken/editMessageText?chat_id=$cchatid2&text=$freecmands&message_id=$cmessage_id2&parse_mode=HTML&reply_markup=$free");
    
    }
    



if ($cdata2 == "herr"){

        $keyboard = [
        'inline_keyboard' => [
             [
             ['text' => 'Gateways 💎', 'callback_data' => 'gates']
             ],
             [
             ['text' => 'Exit 🔄️', 'callback_data' => 'exit']
             ],
       ]
    ];
    $freecmands = urlencode("[🎃] 𝚃𝚘𝚘𝚕𝚜 𝚕𝚒𝚜𝚝 [🎃] 
    
------------------------------------------
[🎃] 𝙲𝚘𝚖𝚊𝚗𝚍𝚘: /gen
𝙵𝚘𝚛𝚖𝚊𝚝: 𝗰𝗰 | 𝗺| 𝘆 | 𝗰𝘃𝘃 
𝚂𝚝𝚊𝚝𝚞𝚜: ✅
    
[🎃]𝙲𝚘𝚖𝚊𝚗𝚍𝚘: /bin
𝙵𝚘𝚛𝚖𝚊𝚝: 𝗰𝗰 | 𝗺| 𝘆 | 𝗰𝘃𝘃 
𝚂𝚝𝚊𝚝𝚞𝚜: ✅
    
[🎃]𝙲𝚘𝚖𝚊𝚗𝚍𝚘: /rand
𝙵𝚘𝚛𝚖𝚊𝚝: US, CA, AU, ES, ETC
𝚂𝚝𝚊𝚝𝚞𝚜: ✅");
    $free = json_encode($keyboard);
            file_get_contents("https://api.telegram.org/bot$botToken/editMessageText?chat_id=$cchatid2&text=$freecmands&message_id=$cmessage_id2&parse_mode=HTML&reply_markup=$free");
    
}


if ($cdata2 == "exit"){

    $keyboard = [
    'inline_keyboard' => [
         [
         ['text' => 'Finalizado ✅', 'callback_data' => 'Close']
         ],
   ]
];
$freecmands = urlencode("<b>Su seccion ah finalizado con exito ✅</b>");
$free = json_encode($keyboard);
        file_get_contents("https://api.telegram.org/bot$botToken/editMessageText?chat_id=$cchatid2&text=$freecmands&message_id=$cmessage_id2&parse_mode=HTML&reply_markup=$free");

}


if ($cdata2 == "Close"){

}




if(strpos($message, "/start")===0 || strpos($message, ".start")===0){
    reply_to($chatId,$message_id,$keyboard,"👾 <b>Welcome</b> 👾%0A%0A🪙• <code>I remind you that this bot works to test credit cards and comes with several tools to make your life easier, For more information contact my Owner by clicking on the bottom button.%0A%0A🪙• In the same way, remember that you can consult my commands by sending</code> /cmds");
}


if(strpos($message, "/cmds") ===0){ 
    $keyboard2 = json_encode([
        'inline_keyboard' => [
        [['text' => "Tools 🛠", 'callback_data' => "herr"],['text' => "Gateways 💎", 'callback_data' => "gates"]],
        ]]);
reply_to($chatId,$message_id,$keyboard2,"<b>🪙• Estas en la seccion de mis Comandos, para saber con que cuento oprime en el boton que desees.</b>");
}


function reply_to($chatId,$message_id,$keyboard,$message) {
    $url = $GLOBALS[website]."/sendMessage?chat_id=".$chatId."&text=".$message."&reply_to_message_id=".$message_id."&parse_mode=HTML&reply_markup=".$keyboard."";
    return file_get_contents($url);
}

function deleteM($chatId,$message_id){

    $url = $GLOBALS[website]."/deleteMessage?chat_id=".$chatId."&message_id=".$message_id."";
    file_get_contents($url);
}


function sendMessage($chatId,$message,$message_id) {

    $url = $GLOBALS[website]."/sendMessage?chat_id=".$chatId."&text=".$message."&reply_to_message_id=".$message_id."&parse_mode=HTML";
    file_get_contents($url);

}


foreach (glob("tools/*.php") as $filename)
{
    include $filename;
}
?>